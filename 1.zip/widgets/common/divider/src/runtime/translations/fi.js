define({
  _widgetLabel: 'Jakaja',
});