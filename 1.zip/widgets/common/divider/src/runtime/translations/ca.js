define({
  _widgetLabel: 'Divisor',
});