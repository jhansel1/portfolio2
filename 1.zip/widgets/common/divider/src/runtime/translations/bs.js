define({
  _widgetLabel: 'Razdjeljivač',
});