export default {
  _widgetLabel: 'Skiller',
}