define({
  _widgetLabel: 'Ogranicznik',
});