define({
  _widgetLabel: 'Oddělovač',
});