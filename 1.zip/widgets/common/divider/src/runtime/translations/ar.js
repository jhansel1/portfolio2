define({
  _widgetLabel: 'المقسم',
});