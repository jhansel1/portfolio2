define({
  _widgetLabel: 'Pemisah',
});