define({
  _widgetLabel: 'Opdeler',
});