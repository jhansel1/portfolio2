define({
  _widgetLabel: 'Trennlinie',
});