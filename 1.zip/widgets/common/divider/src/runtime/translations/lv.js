define({
  _widgetLabel: 'Atdalītājs',
});