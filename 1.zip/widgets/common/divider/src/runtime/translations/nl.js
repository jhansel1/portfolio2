define({
  _widgetLabel: 'Scheider',
});