define({
  _widgetLabel: 'Драйвер',
});