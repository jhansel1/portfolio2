define({
  _widgetLabel: 'Διαχωριστικό',
});