import { QuickStyle } from './components/quick-style';

export default {
  QuickStyle
};