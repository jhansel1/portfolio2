define({
  _layout_REGULAR_label: 'Vanlig',
  _layout_HOVER_label: 'Hover',
  applyTo: 'Bruk på {status}',
  isolate: 'Isoler',
  linkedToAnd: 'Koblet til {where1} og {where2}',
  linkedTo: 'Koblet til {where}',
  placeHolderTip: 'Velg en kortmal.',
  showSelected: 'Vis utvalg',
  _widgetLabel: 'Kort',
});