define({
  _layout_REGULAR_label: 'Regular',
  _layout_HOVER_label: 'Ao sobrepor o cursor',
  applyTo: 'Aplicar a {status}',
  isolate: 'Isolar',
  linkedToAnd: 'Ligado a {where1} e {where2}',
  linkedTo: 'Ligado a {where}',
  placeHolderTip: 'Selecione um modelo de cartão.',
  showSelected: 'Exibir seleção',
  _widgetLabel: 'Cartão',
});