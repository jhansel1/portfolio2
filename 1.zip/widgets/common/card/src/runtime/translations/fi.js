define({
  _layout_REGULAR_label: 'Säännöllinen',
  _layout_HOVER_label: 'Kohoteksti',
  applyTo: 'Käytä tilassa {status}',
  isolate: 'Eristä',
  linkedToAnd: 'Linkitetty kohteisiin {where1} ja {where2}',
  linkedTo: 'Linkitetty kohteeseen {where}',
  placeHolderTip: 'Valitse korttimalli.',
  showSelected: 'Näytä valinta',
  _widgetLabel: 'Kortti',
});