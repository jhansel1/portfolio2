define({
  _layout_REGULAR_label: 'Standard',
  _layout_HOVER_label: 'Survol',
  applyTo: 'Appliquer à {status}',
  isolate: 'Isoler',
  linkedToAnd: 'Lié à {where1} et {where2}',
  linkedTo: 'Lié à {where}',
  placeHolderTip: 'Sélectionnez un modèle de fiche.',
  showSelected: 'Afficher la sélection',
  _widgetLabel: 'Fiche',
});