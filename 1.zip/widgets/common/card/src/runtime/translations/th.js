define({
  _layout_REGULAR_label: 'ปกติ',
  _layout_HOVER_label: 'โฮเวอร์',
  applyTo: 'ใช้กับ {status}',
  isolate: 'แยก',
  linkedToAnd: 'เชื่อมโยงไปยัง {where1} และ {where2}',
  linkedTo: 'เชื่อมโยงไปยัง {where}',
  placeHolderTip: 'โปรดเลือกการ์ดเทมเพลต',
  showSelected: 'แสดงการเลือก',
  _widgetLabel: 'การ์ด',
});