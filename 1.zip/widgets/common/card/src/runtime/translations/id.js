define({
  _layout_REGULAR_label: 'Reguler',
  _layout_HOVER_label: 'Melayang',
  applyTo: 'Terapkan ke {status}',
  isolate: 'Isolasikan',
  linkedToAnd: 'Ditautkan ke {where1} dan {where2}',
  linkedTo: 'Ditautkan ke {where}',
  placeHolderTip: 'Pilih template kartu.',
  showSelected: 'Tampilkan pilihan',
  _widgetLabel: 'Kartu',
});