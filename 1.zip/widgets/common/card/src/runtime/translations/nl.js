define({
  _layout_REGULAR_label: 'Regelmatig',
  _layout_HOVER_label: 'Zweven',
  applyTo: 'Toepassen op {status}',
  isolate: 'Isoleren',
  linkedToAnd: 'Gekoppeld aan {where1} en {where2}',
  linkedTo: 'Gekoppeld aan {where}',
  placeHolderTip: 'Selecteer een kaart-template.',
  showSelected: 'Toon selectie',
  _widgetLabel: 'Card',
});