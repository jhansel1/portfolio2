define({
  _layout_REGULAR_label: 'רגיל',
  _layout_HOVER_label: 'ריחוף',
  applyTo: 'חל על {status}',
  isolate: 'בודד',
  linkedToAnd: 'קשור אל {where1} ואל {where2}',
  linkedTo: 'קשור אל {where}',
  placeHolderTip: 'בחר תבנית כרטיס.',
  showSelected: 'הצג בחירה',
  _widgetLabel: 'כרטיס',
});