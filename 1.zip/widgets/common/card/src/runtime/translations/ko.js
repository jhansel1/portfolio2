define({
  _layout_REGULAR_label: '일반',
  _layout_HOVER_label: '커서 올리기',
  applyTo: '{status}에 적용',
  isolate: '분리',
  linkedToAnd: '{where1} 및 {where2}에 연결됨',
  linkedTo: '{where}에 연결됨',
  placeHolderTip: '카드 템플릿을 선택하세요.',
  showSelected: '선택 영역 표시',
  _widgetLabel: '카드',
});