define({
  _layout_REGULAR_label: 'Regolare',
  _layout_HOVER_label: 'Passaggio del mouse',
  applyTo: 'Applica a {status}',
  isolate: 'Isolare',
  linkedToAnd: 'Collegato a {where1} e {where2}',
  linkedTo: 'Collegato a {where}',
  placeHolderTip: 'Selezionare un modello di scheda.',
  showSelected: 'Mostra selezione',
  _widgetLabel: 'Carta',
});