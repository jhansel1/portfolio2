define({
  _layout_REGULAR_label: 'Normal',
  _layout_HOVER_label: 'Mit der Maus zeigen',
  applyTo: 'Für {status} übernehmen',
  isolate: 'Isolieren',
  linkedToAnd: 'Mit {where1} und {where2} verknüpft',
  linkedTo: 'Mit {where} verknüpft',
  placeHolderTip: 'Wählen Sie eine Kachelvorlage aus.',
  showSelected: 'Auswahl anzeigen',
  _widgetLabel: 'Kachel',
});