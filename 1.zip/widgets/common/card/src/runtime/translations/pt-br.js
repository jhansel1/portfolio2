define({
  _layout_REGULAR_label: 'Regular',
  _layout_HOVER_label: 'Pairar',
  applyTo: 'Aplicar na {status}',
  isolate: 'Isolar',
  linkedToAnd: 'Vinculado a {where1} e {where2}',
  linkedTo: 'Vinculado a {where}',
  placeHolderTip: 'Selecione um modelo de cartão.',
  showSelected: 'Mostrar a seleção',
  _widgetLabel: 'Cartão',
});