define({
  _layout_REGULAR_label: 'Reguljärt',
  _layout_HOVER_label: 'Hovra',
  applyTo: 'Tillämpa på {status}',
  isolate: 'Isolera',
  linkedToAnd: 'Länkad till {where1} och {where2}',
  linkedTo: 'Länkad till {where}',
  placeHolderTip: 'Välj en kortmall.',
  showSelected: 'Visa urval',
  _widgetLabel: 'Kort',
});