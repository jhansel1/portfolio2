define({
  _layout_REGULAR_label: 'Normal',
  _layout_HOVER_label: 'Quan s’apunta',
  applyTo: 'Aplica a {status}',
  isolate: 'Aïlla',
  linkedToAnd: 'Enllaçat a {where1} i {where2}',
  linkedTo: 'Enllaçat a {where}',
  placeHolderTip: 'Seleccioneu una plantilla de targeta.',
  showSelected: 'Mostra la selecció',
  _widgetLabel: 'Targeta',
});