define({
  _layout_REGULAR_label: 'Κανονικό',
  _layout_HOVER_label: 'Κατάδειξη',
  applyTo: 'Εφαρμογή σε {status}',
  isolate: 'Απομόνωση',
  linkedToAnd: 'Επιτυχής σύνδεση με {where1} και {where2}',
  linkedTo: 'Επιτυχής σύνδεση με {where}',
  placeHolderTip: 'Επιλέξτε ένα πρότυπο κάρτας.',
  showSelected: 'Εμφάνιση επιλογής',
  _widgetLabel: 'Κάρτα',
});