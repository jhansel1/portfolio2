define({
  _layout_REGULAR_label: 'Регулярно',
  _layout_HOVER_label: 'При наведении',
  applyTo: 'Применить к {status}',
  isolate: 'Изолировать',
  linkedToAnd: 'Связано с {where1} и с {where2}',
  linkedTo: 'Связано с {where}',
  placeHolderTip: 'Выберите шаблон карточки',
  showSelected: 'Показать выборку',
  _widgetLabel: 'Карточка',
});