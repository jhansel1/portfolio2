define({
  _layout_REGULAR_label: 'Tavaline',
  _layout_HOVER_label: 'Hõljuv',
  applyTo: 'Rakenda olekule {status}',
  isolate: 'Isoleeri',
  linkedToAnd: 'Lingitud asukohtadega {where1} ja {where2}',
  linkedTo: 'Lingitud asukohaga {where}',
  placeHolderTip: 'Valige kaardimall.',
  showSelected: 'Kuva valik',
  _widgetLabel: 'Kaart',
});