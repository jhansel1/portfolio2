define({
  _layout_REGULAR_label: 'Regularno',
  _layout_HOVER_label: 'Zadržavanje pokazivača miša',
  applyTo: 'Primeni na {status}',
  isolate: 'Izoluj',
  linkedToAnd: 'Povezano na {where1} i {where2}',
  linkedTo: 'Povezano na {where}',
  placeHolderTip: 'Selektujte šablon kartice.',
  showSelected: 'Prikaži izbor',
  _widgetLabel: 'Kartica',
});