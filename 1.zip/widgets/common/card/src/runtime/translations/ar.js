define({
  _layout_REGULAR_label: 'منتظم',
  _layout_HOVER_label: 'تحويم',
  applyTo: 'تطبيق على {status}',
  isolate: 'عزل',
  linkedToAnd: 'مرتبط بـ {where1} و{where2}',
  linkedTo: 'مرتبط بـ {where}',
  placeHolderTip: 'يرجى تحديد قالب بطاقة.',
  showSelected: 'عرض التحديد',
  _widgetLabel: 'بطاقة',
});