define({
  _widgetLabel: 'Изображение',
  imageChooseShape: 'Форма',
  imageCrop: 'Обрезать'
});