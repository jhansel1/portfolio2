define({
  _widgetLabel: 'الصورة',
  imageChooseShape: 'الشكل',
  imageCrop: 'قص'
});