define({
  _widgetLabel: 'Slika',
  imageChooseShape: 'Oblika',
  imageCrop: 'Obreži'
});