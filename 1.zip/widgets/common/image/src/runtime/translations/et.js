define({
  _widgetLabel: 'Pilt',
  imageChooseShape: 'Kuju',
  imageCrop: 'Kärbi'
});