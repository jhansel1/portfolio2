define({
  _widgetLabel: 'Hình ảnh',
  imageChooseShape: 'Hình dạng',
  imageCrop: 'Cắt'
});