define({
  _widgetLabel: 'Image',
  imageChooseShape: 'Vorm',
  imageCrop: 'Bijsnijden'
});