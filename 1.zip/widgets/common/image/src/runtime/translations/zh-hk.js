define({
  _widgetLabel: '圖片',
  imageChooseShape: '形狀',
  imageCrop: '裁剪'
});