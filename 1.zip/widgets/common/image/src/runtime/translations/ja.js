define({
  _widgetLabel: '画像',
  imageChooseShape: '図形',
  imageCrop: 'トリミング'
});