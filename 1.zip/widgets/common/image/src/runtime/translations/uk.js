define({
  _widgetLabel: 'Зображення',
  imageChooseShape: 'Форма',
  imageCrop: 'Обрізка'
});