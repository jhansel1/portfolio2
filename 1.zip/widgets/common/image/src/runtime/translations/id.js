define({
  _widgetLabel: 'Gambar',
  imageChooseShape: 'Bentuk',
  imageCrop: 'Potong'
});