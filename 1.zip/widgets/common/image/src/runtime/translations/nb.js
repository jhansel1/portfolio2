define({
  _widgetLabel: 'Bilde',
  imageChooseShape: 'Form',
  imageCrop: 'Beskjær'
});