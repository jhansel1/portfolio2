define({
  _widgetLabel: 'Snimak',
  imageChooseShape: 'Oblik',
  imageCrop: 'Skrati'
});