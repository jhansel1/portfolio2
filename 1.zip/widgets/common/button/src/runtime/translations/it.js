define({
  _widgetLabel: 'Pulsante'
});