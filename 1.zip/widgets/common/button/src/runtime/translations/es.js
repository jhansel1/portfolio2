define({
  _widgetLabel: 'Botón'
});