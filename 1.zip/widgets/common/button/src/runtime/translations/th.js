define({
  _widgetLabel: 'ปุ่ม'
});