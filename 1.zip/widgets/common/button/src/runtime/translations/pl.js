define({
  _widgetLabel: 'Przycisk'
});