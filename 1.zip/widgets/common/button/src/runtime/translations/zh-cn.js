define({
  _widgetLabel: '按钮'
});