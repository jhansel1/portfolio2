define({
  _widgetLabel: '按鈕'
});