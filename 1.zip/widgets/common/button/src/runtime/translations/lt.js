define({
  _widgetLabel: 'Mygtukas'
});