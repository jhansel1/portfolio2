define({
  _widgetLabel: 'Dugme'
});