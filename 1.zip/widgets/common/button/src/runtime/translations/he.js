define({
  _widgetLabel: 'לחצן'
});