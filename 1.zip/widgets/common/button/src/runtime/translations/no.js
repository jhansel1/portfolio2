export default {
  _widgetLabel: 'Knapp'
}