define({
  _widgetLabel: 'Knapp'
});