define({
  _widgetLabel: 'Gomb'
});