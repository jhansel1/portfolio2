define({
  _widgetLabel: 'Knop'
});