define({
  _widgetLabel: 'Painike'
});