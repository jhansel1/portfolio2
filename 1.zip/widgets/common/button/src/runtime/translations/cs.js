define({
  _widgetLabel: 'Tlačítko'
});