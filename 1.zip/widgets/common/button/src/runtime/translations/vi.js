define({
  _widgetLabel: 'Nút'
});