define({
  _widgetLabel: 'Botó'
});