define({
  _widgetLabel: 'Knap'
});