define({
  _widgetLabel: 'ปุ่มกด'
});